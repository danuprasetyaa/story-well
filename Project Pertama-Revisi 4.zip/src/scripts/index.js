// 1. Impor Model (data source) dan View (DOM manager), bukan fungsi render individual
import StoryApiSource from './data/story-api-source.js';
import MainView from './view/main-view.js';
import '../styles/style.css';

// 2. Inisiasi View
// View dibuat sekali dan akan digunakan oleh Presenter untuk memanipulasi DOM
const view = new MainView();

// 3. Definisikan logika aplikasi (Handlers)
// Ini adalah fungsi-fungsi yang akan dipanggil oleh View saat ada interaksi dari pengguna
const App = {
  async login(email, password) {
    const loginResult = await StoryApiSource.login(email, password);
    sessionStorage.setItem('authToken', loginResult.token);
    sessionStorage.setItem('userName', loginResult.name);
    window.location.hash = '#/';
  },

  async register(name, email, password) {
    await StoryApiSource.register(name, email, password);
    alert('Registrasi berhasil! Silakan login.');
    window.location.hash = '#/login';
  },

  async addStory(formData) {
    await StoryApiSource.postStory(formData);
  },
};

// ==========================================================
// FUNGSI HELPER (Tetap di sini karena mengontrol state global)
// ==========================================================

function isUserLoggedIn() {
  return !!sessionStorage.getItem('authToken');
}

function updateNavLinksVisibility() {
  const isLoggedIn = isUserLoggedIn();
  const dashboardLink = document.getElementById('dashboard-link');
  const addStoryLink = document.getElementById('add-story-link');
  const logoutButton = document.getElementById('logout-button');

  if (!dashboardLink || !addStoryLink || !logoutButton) return;

  if (isLoggedIn) {
    dashboardLink.style.display = 'inline';
    addStoryLink.style.display = 'inline';
    logoutButton.style.display = 'inline-block';
  } else {
    dashboardLink.style.display = 'none';
    addStoryLink.style.display = 'none';
    logoutButton.style.display = 'none';
  }
}

// ==========================================================
// PRESENTER UTAMA: Menghubungkan URL, Model, dan View
// ==========================================================

// Daftar rute sekarang berisi fungsi yang mengorkestrasi Model dan View
const routes = {
  '/': async () => {
    const stories = await StoryApiSource.getStories();
    const userName = sessionStorage.getItem('userName') || 'User';
    view.renderDashboard(stories, userName);
  },
  '/add': () => {
    view.renderAddStoryPage(App.addStory);
  },
  '/login': () => {
    view.renderLoginPage(App.login);
  },
  '/register': () => {
    view.renderRegisterPage(App.register);
  },
};

function handleRouteChange() {
  const hash = window.location.hash || '#/';
  const route = hash.substring(1);
  
  // Logika "Penjaga Gerbang" tetap sama
  const isProtectedRoute = ['/', '/add'].includes(route);
  if (isProtectedRoute && !isUserLoggedIn()) {
    window.location.hash = '#/login';
    return;
  }
  if (route === '/login' && isUserLoggedIn()) {
    window.location.hash = '#/';
    return;
  }
  
  // Atur layout dan visibilitas navigasi
  const authRoutes = ['/login', '/register'];
  document.body.classList.toggle('auth-page', authRoutes.includes(route));
  updateNavLinksVisibility();

  // Panggil fungsi Presenter yang sesuai dengan rute
  const pageRenderer = routes[route] || routes['/'];
  if (document.startViewTransition) {
    document.startViewTransition(() => pageRenderer());
  } else {
    pageRenderer();
  }
}

// ==========================================================
// EVENT LISTENERS
// ==========================================================

window.addEventListener('DOMContentLoaded', () => {
  handleRouteChange();

  const logoutButton = document.getElementById('logout-button');
  if (logoutButton) {
    logoutButton.addEventListener('click', (event) => {
      event.preventDefault();
      sessionStorage.clear();
      window.location.hash = '#/login';
      handleRouteChange();
    });
  }
});

window.addEventListener('hashchange', handleRouteChange);