// 1. LENGKAPI IMPORT: Tambahkan 'login' dan 'register'
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
// Gambar Maker
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';


import { getStories, postStory, login, register } from './api.js';

L.Icon.Default.mergeOptions({
  iconUrl: markerIcon,
  iconRetinaUrl: markerIcon2x,
  shadowUrl: markerShadow,
});

const appContent = document.getElementById('app-content');
let mapInstance; // Simpan referensi peta agar bisa diakses

// ==========================================================
// VIEW & LOGIC: HALAMAN LOGIN
// ==========================================================

export function renderLoginPage() {
    // HANYA ADA SATU FUNGSI INI, VERSI YANG SUDAH LENGKAP
    appContent.innerHTML = `
        <div class="card" style="max-width: 500px; margin: 2rem auto;">
            <h2 class="logo">Login to Story Well</h2>
            <form id="login-form">
                <label for="email">Email</label>
                <input type="email" id="email" required>
                
                <label for="password">Password</label>
                <input type="password" id="password" required>

                <button type="submit" style="margin-top: 1.5rem;">Login</button>
                <p id="login-error" style="color: red;"></p>
                
                <p style="margin-top: 1rem; text-align: center;">
                    Belum punya akun? <a href="#/register">Daftar di sini</a>
                </p>
            </form>
        </div>
    `;
    initLoginForm();
}

function initLoginForm() {
    const form = document.getElementById('login-form');
    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const errorEl = document.getElementById('login-error');
        try {
            const email = form.email.value;
            const password = form.password.value;
            const loginResult = await login(email, password);

            sessionStorage.setItem('authToken', loginResult.token);
            sessionStorage.setItem('userName', loginResult.name);

            window.location.hash = '#/';
        } catch (error) {
            errorEl.textContent = error.message;
        }
    });
}

// ==========================================================
// VIEW & LOGIC: HALAMAN REGISTRASI (YANG SEBELUMNYA HILANG)
// ==========================================================

export function renderRegisterPage() {
    appContent.innerHTML = `
        <div class="card" style="max-width: 500px; margin: 2rem auto;">
            <h2 class="logo">Create Account</h2>
            <form id="register-form">
                <label for="name">Name</label>
                <input type="text" id="name" required>
                
                <label for="email">Email</label>
                <input type="email" id="email" required>
                
                <label for="password">Password (min. 8 characters)</label>
                <input type="password" id="password" required minlength="8">

                <button type="submit" style="margin-top: 1.5rem;">Register</button>
                <p id="register-error" style="color: red;"></p>
            </form>
        </div>
    `;
    initRegisterForm();
}

function initRegisterForm() {
    const form = document.getElementById('register-form');
    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const errorEl = document.getElementById('register-error');
        try {
            const name = form.name.value;
            const email = form.email.value;
            const password = form.password.value;

            await register(name, email, password);

            alert('Registrasi berhasil! Silakan login.');
            window.location.hash = '#/login';
        } catch (error) {
            errorEl.textContent = error.message;
        }
    });
}


// ==========================================================
// VIEW & LOGIC: HALAMAN UTAMA (DASHBOARD)
// ==========================================================
export function renderDashboard() {
    appContent.innerHTML = `
        <div class="dashboard-grid">
            <section id="story-list" class="story-list" aria-labelledby="stories-heading">
                <h2 id="stories-heading" class="logo">Latest Stories</h2>
                <p>Loading stories from the Verse...</p>
            </section>
            <aside class="map-container" id="map-container" aria-label="Stories Location Map"></aside>
        </div>
    `;
    initDashboard();
}

async function initDashboard() {
    const storyListEl = document.getElementById('story-list');
    
    mapInstance = L.map('map-container').setView([-2.548926, 118.0148634], 5);
    const openStreetMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    });
    const satelliteMap = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: 'Tiles &copy; Esri'
    });
    openStreetMap.addTo(mapInstance);

    L.control.layers({ "Streets": openStreetMap, "Satellite": satelliteMap }).addTo(mapInstance);

    const stories = await getStories();
    const userName = sessionStorage.getItem('userName') || 'User';
    storyListEl.innerHTML = `<h2 class="logo">Latest Stories for ${userName}</h2>`;

    if (stories.length === 0) {
        storyListEl.innerHTML += `<p>No stories found.</p>`;
        return;
    }

    stories.forEach(story => {
        const storyCard = document.createElement('article');
        storyCard.className = 'card story-card';
        storyCard.innerHTML = `
            <img src="${story.photoUrl}" alt="${story.description.substring(0, 50)}...">
            <h3>${story.name}</h3>
            <p>${story.description}</p>
        `;
        storyListEl.appendChild(storyCard);

        if (story.lat && story.lon) {
            const marker = L.marker([story.lat, story.lon])
                .addTo(mapInstance)
                .bindPopup(`<b>${story.name}</b>`);

            storyCard.addEventListener('click', () => {
                mapInstance.flyTo([story.lat, story.lon], 13);
                marker.openPopup();
            });
        }
    });
}

// ==========================================================
// VIEW & LOGIC: HALAMAN TAMBAH CERITA
// ==========================================================
export function renderAddStory() {
    appContent.innerHTML = `
        <h2 class="logo">Post New Story</h2>
        <form id="add-story-form" class="card" novalidate>
            <div class="form-grid">
                <div>
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="5" required minlength="10"></textarea>

                    <label for="photo">Upload Photo</label>
                    <input type="file" id="photo" name="photo" accept="image/*" required>
                    
                    <div class="camera-container" style="margin-top: 1rem;">
                        <video id="camera-preview" autoplay playsinline style="display:none;"></video>
                        <button type="button" id="open-camera-btn">Use Camera</button>
                        <button type="button" id="capture-btn" style="display:none;">Capture Photo</button>
                    </div>
                </div>
                <div>
                    <p>Click on the map to select story location</p>
                    <div id="map-picker" class="map-container" style="height: 300px;"></div>
                    <input type="hidden" id="lat" name="lat" required>
                    <input type="hidden" id="lon" name="lon" required>
                </div>
            </div>
            <button type="submit" id="submit-btn" style="margin-top: 1rem; width: 100%;">Post to the Verse</button>
            <p id="error-message" style="color: red; margin-top: 1rem;"></p>
        </form>
    `;
    initAddStoryForm();
}

function initAddStoryForm() {
    const form = document.getElementById('add-story-form');
    const latInput = document.getElementById('lat');
    const lonInput = document.getElementById('lon');
    const errorMessage = document.getElementById('error-message');

    const mapPicker = L.map('map-picker').setView([-2.548926, 118.0148634], 5);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(mapPicker);
    let locationMarker;

    mapPicker.on('click', (e) => {
        const { lat, lng } = e.latlng;
        latInput.value = lat;
        lonInput.value = lng;
        
        if (locationMarker) {
            locationMarker.setLatLng(e.latlng);
        } else {
            locationMarker = L.marker(e.latlng).addTo(mapPicker);
        }
        mapPicker.panTo(e.latlng);
    });

    const videoEl = document.getElementById('camera-preview');
    const openCameraBtn = document.getElementById('open-camera-btn');
    const captureBtn = document.getElementById('capture-btn');
    const photoInput = document.getElementById('photo');
    let stream;

    openCameraBtn.addEventListener('click', async () => {
        try {
            stream = await navigator.mediaDevices.getUserMedia({ video: true });
            videoEl.srcObject = stream;
            videoEl.style.display = 'block';
            captureBtn.style.display = 'inline-block';
            openCameraBtn.style.display = 'none';
        } catch (err) {
            errorMessage.textContent = 'Camera access denied or not available.';
        }
    });

    captureBtn.addEventListener('click', () => {
        const canvas = document.createElement('canvas');
        canvas.width = videoEl.videoWidth;
        canvas.height = videoEl.videoHeight;
        canvas.getContext('2d').drawImage(videoEl, 0, 0);
        
        canvas.toBlob(blob => {
            const file = new File([blob], "camera-shot.jpg", { type: "image/jpeg" });
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            photoInput.files = dataTransfer.files;
        }, 'image/jpeg');

        stream.getTracks().forEach(track => track.stop());
        videoEl.style.display = 'none';
        captureBtn.style.display = 'none';
        openCameraBtn.style.display = 'inline-block';
    });

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        errorMessage.textContent = '';
        
        if (!form.checkValidity()) {
            errorMessage.textContent = 'Please fill all required fields correctly.';
            return;
        }

        const submitBtn = document.getElementById('submit-btn');
        submitBtn.textContent = 'Posting...';
        submitBtn.disabled = true;

        const formData = new FormData();
        formData.append('description', form.description.value);
        formData.append('photo', form.photo.files[0]);
        formData.append('lat', form.lat.value);
        formData.append('lon', form.lon.value);

        try {
            await postStory(formData);
            alert('Story posted successfully!');
            window.location.hash = '#/';
        } catch (error) {
            errorMessage.textContent = `Error: ${error.message}`;
        } finally {
            submitBtn.textContent = 'Post to the Verse';
            submitBtn.disabled = false;
        }
    });
}