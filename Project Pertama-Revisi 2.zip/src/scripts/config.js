// Ganti dengan URL API yang sebenarnya
export const API_BASE_URL = 'https://story-api.dicoding.dev/v1'; 

// Jika API membutuhkan otentikasi, simpan token di sini
// Sebaiknya, token didapatkan dari proses login, tapi untuk submission ini bisa di-hardcode
export const AUTH_TOKEN = 'BCCs2eonMI-6H2ctvFaWg-UYdDv387Vno_bzUzALpB442r2lCnsHmtrx8biyPi_E-1fSGABK_Qs_GlvPoJJqxbk';