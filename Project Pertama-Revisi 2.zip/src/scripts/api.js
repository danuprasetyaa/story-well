import { API_BASE_URL } from './config.js';

// ==========================================================
// FUNGSI HELPER UNTUK MENGAMBIL TOKEN
// ==========================================================

/**
 * Mengambil token autentikasi dari sessionStorage.
 * @returns {string|null} Token atau null jika tidak ada.
 */
function getAuthToken() {
    return sessionStorage.getItem('authToken');
}


// ==========================================================
// FUNGSI UNTUK AUTENTIKASI (LOGIN & REGISTER)
// ==========================================================

/**
 * Mengirim permintaan login ke API.
 * @param {string} email 
 * @param {string} password 
 * @returns {Promise<object>} Hasil login yang berisi data user dan token.
 */
export async function login(email, password) {
    try {
        const response = await fetch(`${API_BASE_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
        });
        const result = await response.json();
        if (result.error) {
            throw new Error(result.message);
        }
        return result.loginResult;
    } catch (error) {
        console.error("Login failed:", error);
        throw error;
    }
}

/**
 * Mengirim permintaan register ke API.
 * @param {string} name 
 * @param {string} email 
 * @param {string} password 
 * @returns {Promise<object>} Hasil registrasi.
 */
export async function register(name, email, password) {
    try {
        const response = await fetch(`${API_BASE_URL}/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, password }),
        });
        const result = await response.json();
        if (result.error) {
            throw new Error(result.message);
        }
        return result;
    } catch (error) {
        console.error("Registration failed:", error);
        throw error;
    }
}


// ==========================================================
// FUNGSI UNTUK MENGELOLA STORIES
// ==========================================================

/**
 * Mengambil semua cerita dari API.
 * Membutuhkan token autentikasi.
 * @returns {Promise<Array>} Daftar cerita.
 */
export async function getStories() {
    const token = getAuthToken();
    if (!token) {
        // Jika tidak ada token, paksa user untuk login
        console.warn("No auth token found. Redirecting to login.");
        window.location.hash = '#/login';
        return []; // Kembalikan array kosong agar tidak error
    }

    try {
        const response = await fetch(`${API_BASE_URL}/stories`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.status === 401) {
            // Jika token tidak valid/kadaluarsa, paksa login lagi
            sessionStorage.removeItem('authToken');
            window.location.hash = '#/login';
            return [];
        }

        const data = await response.json();
        if (data.error) throw new Error(data.message);
        
        return data.listStory;
    } catch (error) {
        console.error("Failed to fetch stories:", error);
        return [];
    }
}

/**
 * Mengirim cerita baru ke API.
 * Membutuhkan token autentikasi.
 * @param {FormData} formData Data cerita termasuk deskripsi dan foto.
 * @returns {Promise<object>} Hasil dari API.
 */
export async function postStory(formData) {
    const token = getAuthToken();
    if (!token) {
        console.warn("No auth token found. Redirecting to login.");
        window.location.hash = '#/login';
        throw new Error("You must be logged in to post a story.");
    }

    try {
        const response = await fetch(`${API_BASE_URL}/stories`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            },
            body: formData,
        });

        const result = await response.json();
        if (result.error) {
            throw new Error(result.message);
        }
        return result;
    } catch (error) {
        console.error("Error posting story:", error);
        throw error;
    }
}