import { renderDashboard, renderAddStory, renderLoginPage, renderRegisterPage } from './views.js';
import '../styles/style.css';


// ==========================================================
// KONFIGURASI ROUTER
// ==========================================================

const routes = {
    '/': renderDashboard,
    '/add': renderAddStory,
    '/login': renderLoginPage,
    '/register': renderRegisterPage,
};

const protectedRoutes = ['/', '/add'];

// ==========================================================
// FUNGSI HELPER
// ==========================================================

/**
 * Memeriksa apakah user sudah login (punya token).
 * @returns {boolean} True jika sudah login, false jika belum.
 */
function isUserLoggedIn() {
    return !!sessionStorage.getItem('authToken');
}

/**
 * Mengatur tampilan link navigasi di header berdasarkan status login.
 */
function updateNavLinksVisibility() {
    const isLoggedIn = isUserLoggedIn();
    const dashboardLink = document.getElementById('dashboard-link');
    const addStoryLink = document.getElementById('add-story-link');
    const logoutButton = document.getElementById('logout-button');

    if (!dashboardLink || !addStoryLink || !logoutButton) {
        // Hentikan jika elemen navigasi tidak ditemukan (untuk mencegah error)
        return;
    }

    if (isLoggedIn) {
        // Jika login, tampilkan navigasi utama dan tombol logout
        dashboardLink.style.display = 'inline';
        addStoryLink.style.display = 'inline';
        logoutButton.style.display = 'inline-block';
    } else {
        // Jika tidak login, sembunyikan
        dashboardLink.style.display = 'none';
        addStoryLink.style.display = 'none';
        logoutButton.style.display = 'none';
    }
}

// ==========================================================
// FUNGSI UTAMA ROUTER (PENJAGA GERBANG)
// ==========================================================

/**
 * Fungsi ini bertindak sebagai penjaga gerbang.
 * Ia akan dipanggil setiap kali URL hash berubah atau halaman dimuat.
 */
function handleRouteChange() {
    const hash = window.location.hash || '#/';
    const route = hash.substring(1);

    // Mengatur class layout di <body>
    const authRoutes = ['/login', '/register'];
    if (authRoutes.includes(route)) {
        document.body.classList.add('auth-page');
    } else {
        document.body.classList.remove('auth-page');
    }

    // Memeriksa apakah rute dilindungi
    const isProtectedRoute = protectedRoutes.includes(route);
    if (isProtectedRoute && !isUserLoggedIn()) {
        window.location.hash = '#/login';
        return;
    }

    // Mencegah user yang sudah login mengakses halaman login
    if (route === '/login' && isUserLoggedIn()) {
        window.location.hash = '#/';
        return;
    }

    // Memperbarui visibilitas navigasi setiap pindah halaman
    updateNavLinksVisibility();

    // Menampilkan halaman yang sesuai
    const pageRenderer = routes[route] || routes['/'];
    if (document.startViewTransition) {
        document.startViewTransition(() => pageRenderer());
    } else {
        pageRenderer();
    }
}

// ==========================================================
// EVENT LISTENERS
// ==========================================================

// Event listener ini berjalan SEKALI saat halaman selesai dimuat
window.addEventListener('DOMContentLoaded', () => {
    // 1. Inisialisasi halaman saat pertama kali dibuka
    handleRouteChange();

    // 2. Pasang fungsi logout pada tombolnya
    const logoutButton = document.getElementById('logout-button');
    if (logoutButton) {
        logoutButton.addEventListener('click', (event) => {
            event.preventDefault();
            sessionStorage.clear(); // Hapus semua data sesi (termasuk token)
            window.location.hash = '#/login'; // Arahkan ke halaman login
            handleRouteChange(); // Perbarui UI segera
        });
    }
});

// Event listener ini berjalan SETIAP KALI link hash berubah
window.addEventListener('hashchange', handleRouteChange);